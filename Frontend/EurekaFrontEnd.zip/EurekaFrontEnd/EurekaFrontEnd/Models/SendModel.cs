﻿namespace EurekaFrontEnd.Models
{
    public class SendModel
    {
        public string question { get; set; }
        public string a { get; set; }
        public string b { get; set; }
        public string c { get; set; }
        public string d { get; set; }
        public string e { get; set; }
    }
}
