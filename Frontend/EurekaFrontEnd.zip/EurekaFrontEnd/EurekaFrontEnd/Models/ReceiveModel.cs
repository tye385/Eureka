﻿namespace EurekaFrontEnd.Models
{
    public class ReceiveModel
    {
        public string answer { get; set; }
    }
}
